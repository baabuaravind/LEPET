<span class='crayon-popup'>
  <span <?php print drupal_attributes($label_attr) ?>>
    <span <?php print drupal_attributes($attr) ?>></span>
    <?php print $label ?>
  </span>
</span>
