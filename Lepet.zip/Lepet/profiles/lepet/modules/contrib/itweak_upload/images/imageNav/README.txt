Images in images/imageNav/* directories are kept as a source for compound images/imageNav*.png that are used to show button icons with CSS sprites technique. 

There is single image generated for each button, with all icons stacked horizontally with 2x spacing with the following order:
Normal -space- Hover -space- Clicked

e.g. The buttons are 27x27 px. 3 button views plus same-size space gives 5x27px = 135px wide.
