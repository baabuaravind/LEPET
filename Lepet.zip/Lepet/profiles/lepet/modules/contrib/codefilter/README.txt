ABOUT

  This is a simple filter module. It handles <code></code> and <?php ?> tags so
  that users can post code without having to worry about escaping with &lt; and
  &gt;


INSTALLATION

  See the INSTALL.txt file for important installation instructions.


CURRENT MAINTAINER

  John Wilkins - JohnAlbin on Drupal.org


CREDITS

  This mini-module was made by Steven Wittens <unconed@drupal.org>, based on the
  PHP filter in Kjartan Mannes's <kjartan@drupal.org> project.module.
